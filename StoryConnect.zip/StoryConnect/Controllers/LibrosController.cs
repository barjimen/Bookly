﻿using Microsoft.AspNetCore.Mvc;
using StoryConnect.Models;
using StoryConnect.Repositories;

namespace StoryConnect.Controllers
{
    public class LibrosController : Controller
    {
        private IRepositoryLibros repo;
        public LibrosController(IRepositoryLibros repo)
        {
            this.repo = repo;
        }
        public async Task<IActionResult> Index()
        {
            List<Libros> libro = 
                await this.repo.GetLibrosAsync();
            return View(libro);
        }

        public async Task<IActionResult> Detalles(int id)
        {
            Libros libro =
                await this.repo.FindLibros(id);
            return View(libro);
        }

        public JsonResult Buscar(string searchTerm)
        {
            var libros = this.repo.BuscarLibros(searchTerm);
            return Json(libros.Select(l => new { l.Titulo, l.NombreAutor }).ToList());
        }
    }
}
